#ifndef INC_3_polynomialS_polynomial_H
#define INC_3_polynomialS_polynomial_H

#include <iostream>
#include <list>
#include <string>
#include <regex>
#include <vector>
#include <algorithm>

using std::list;
using std::string;
using std::cout;
using std::endl;
using std::regex;
using std::smatch;
using std::regex_match;
using std::sregex_iterator;

class polynomial
{
public:
    using power_t = int;
    struct Monom {
        double coef;
        power_t power;
    };

    polynomial ();
    explicit polynomial (string && pattern);
    explicit polynomial (const list<Monom> & instance);
    explicit polynomial (const Monom && instance);

    polynomial (const polynomial & instance);

    ~polynomial ();

    static bool compare (const Monom & left, const Monom & right);
    static void groupUp (list<Monom> & instance);
    static void deepcopy (const list<Monom> & from, list<Monom> & to);
    static void purify (list<Monom> & instance);
    static bool match (const string & instance);
    static const regex& polynomialPattern ();
    static const regex& additionPattern ();

    polynomial& operator= (const polynomial & instance);

    friend polynomial operator+ (const polynomial & left, const polynomial & right);
    polynomial& operator+= (const polynomial & other);

    polynomial operator- () const;

    friend polynomial operator- (const polynomial & left, const polynomial & right);
    polynomial& operator-= (const polynomial & other);

    friend polynomial operator* (const polynomial & base, int multiplier);
    friend polynomial operator* (const int multiplier, const polynomial & base);
    polynomial& operator*= (int multiplier);

    friend polynomial operator* (const polynomial & base, double multiplier);
    friend polynomial operator* (double multiplier, const polynomial & base);
    polynomial& operator*= (double multiplier);

    friend polynomial operator* (const polynomial & base, const Monom & multiplier);
    friend polynomial operator* (const Monom & multiplier, const polynomial & base);
    polynomial& operator*= (const Monom & multiplier);

    friend polynomial operator* (const polynomial & left, const polynomial & right);
    polynomial& operator*= (const polynomial & other);

    friend polynomial operator/ (const polynomial & base, double divider);
    polynomial& operator/= (double divider);

    friend polynomial operator/ (const polynomial & base, const Monom & divider);
    polynomial& operator/= (const Monom & divider);

    friend polynomial operator/ (const polynomial & base, const polynomial & divider);
    polynomial& operator/= (const polynomial & divider);

    friend bool operator== (const polynomial & left, const polynomial & right);
    friend bool operator!= (const polynomial & left, const polynomial & right);

    polynomial pow (unsigned power) const;
    double super (double x) const;
    polynomial super (const polynomial & x) const;

    bool empty () const;
    bool zero () const;
    const Monom& head () const;
    void clear ();
    unsigned length () const;
    power_t power () const;

    void print () const;

private:
    list<Monom> monoms;
};

#endif
