#include "polynomial.h"

double powf (const double base, unsigned power)
{
    double result = base;
    while (power > 1)
    {
        result *= base;
        --power;
    }
    return result;
}

polynomial::polynomial () = default;

polynomial::polynomial (string && pattern)
{
    Monom temp {};
    pattern.erase (remove (pattern.begin (), pattern.end (), ' '), pattern.end ());
    if (pattern[0] != '-' && pattern[0] != '+') pattern.insert (pattern.begin (), '+');
    std::vector<size_t> edges;
    for (size_t i=0; i<pattern.size (); ++i)
    {
        if (pattern[i] == '+' || pattern[i] == '-')
        {
            edges.push_back (i);
        }
    }

    size_t i, j=0;
    for (const size_t edge : edges)
    {
        temp.power = 0;
        temp.coef = (pattern[edge] == '-') ? -1.0f : 1.0f;
        i = edge + 1;
        while (pattern[i+j] == '.' || (pattern[i+j] >= '0' && pattern[i+j] <= '9')) ++j;
        if (j > 0) temp.coef *= std::stof (pattern.substr (i, j));
        i += j;
        if (pattern[i] == 'x')
        {
            temp.power = 1;
            if (pattern[++i] == '^')
            {
                j = 0;
                ++i;
                while (pattern[i+j] >= '0' && pattern[i+j] <= '9') ++j;
                if (j > 0) temp.power = std::stoi (pattern.substr (i, j));
            }
        }
        this->monoms.push_back (
            Monom {
                .coef = temp.coef,
                .power = temp.power
            }
        );
        j=0;
    }
    this->monoms.sort (compare);
    groupUp (this->monoms);

}
polynomial::polynomial (const Monom && instance)
{
    this->monoms.push_back (
        Monom {
            .coef = instance.coef,
            .power = instance.power
        }
    );
}
polynomial::polynomial (const list<Monom> & instance)
{
    deepcopy (instance, this->monoms);
}

polynomial::~polynomial () = default;

polynomial::polynomial (const polynomial &instance)
{
    deepcopy (instance.monoms, this->monoms);
}
polynomial& polynomial::operator= (const polynomial & instance)
{
    this->monoms.clear ();
    for (const auto & monom : instance.monoms)
    {
        this->monoms.push_back (
            Monom {
                .coef = monom.coef,
                .power = monom.power
            }
        );
    }
    return *this;
}

bool polynomial::compare (const Monom & left, const Monom & right)
{
    return (left.power > right.power);
}
void polynomial::groupUp (list<Monom> & instance)
{

    if (!instance.empty ())
    {
        auto prev = instance.begin ();
        for (auto current = ++instance.begin (); current != instance.end ();)
        {
            if (prev->power == current->power)
            {
                current->coef += prev->coef;
                current = instance.erase (prev);
            }
            prev = current++;
        }
    }
    purify (instance);
}
void polynomial::deepcopy (const list<Monom> & from, list<Monom> & to)
{
    for (const auto & item : from)
    {
        to.push_back (
            Monom {
                .coef = item.coef,
                .power = item.power
            }
        );
    }
}
void polynomial::purify (list<Monom> & instance)
{
    for (auto item = instance.cbegin (); item != instance.cend ();)
    {
        if (item->coef == 0.0f)
            item = instance.erase (item);
        else
            ++item;
    }
}
bool polynomial::match (const string & instance)
{
    return regex_match (instance, polynomialPattern ());
}

const regex& polynomial::polynomialPattern ()
{
    static const regex pattern  ("(\\s*(\\+|-)?\\s*((([0-9.]+)(x(\\^[0-9]+)?)?)|([0-9.]+)?x(\\^[0-9]+)?))+");

    return pattern;
}

polynomial operator+ (const polynomial & left, const polynomial & right)
{
    list<polynomial::Monom> leftList;
    polynomial::deepcopy (left.monoms, leftList);
    list<polynomial::Monom> rightList;
    polynomial::deepcopy (right.monoms, rightList);
    leftList.merge (rightList, polynomial::compare);
    polynomial::groupUp (leftList);
    return polynomial (leftList);
}
polynomial& polynomial::operator+= (const polynomial & other)
{
    list<Monom> others;
    deepcopy (other.monoms, others);
    this->monoms.merge (others, compare);
    groupUp (this->monoms);
    return *this;
}

polynomial polynomial::operator- () const
{
    list<Monom> instance;
    deepcopy (this->monoms, instance);
    for (auto & item : instance)
    {
        item.coef = -item.coef;
    }
    return polynomial (instance);
}
polynomial operator- (const polynomial & left, const polynomial & right)
{
    return left + (-right);
}
polynomial& polynomial::operator-= (const polynomial & other)
{
    polynomial temp = -other;
    this->monoms.merge (temp.monoms, compare);
    groupUp (this->monoms);
    return *this;
}

polynomial operator* (const polynomial & base, const int multiplier)
{
    list<polynomial::Monom> instance;
    polynomial::deepcopy (base.monoms, instance);
    for (auto & item : instance)
    {
        item.coef *= multiplier;
    }
    return polynomial (instance);
}
polynomial& polynomial::operator*= (const int multiplier)
{
    for (auto & item : this->monoms)
    {
        item.coef *= multiplier;
    }
    return *this;
}
polynomial operator* (const int multiplier, const polynomial & base)
{
    return base * multiplier;
}
polynomial operator* (const polynomial & base, const double multiplier)
{
    list<polynomial::Monom> instance;
    polynomial::deepcopy (base.monoms, instance);
    for (auto & item : instance)
    {
        item.coef *= multiplier;
    }
    return polynomial (instance);
}
polynomial operator* (const double multiplier, const polynomial & base)
{
    return base * multiplier;
}

polynomial& polynomial::operator*= (const double multiplier)
{
    for (auto & item : this->monoms)
    {
        item.coef *= multiplier;
    }
    return *this;
}
polynomial operator* (const polynomial & base, const polynomial::Monom & multiplier)
{
    list<polynomial::Monom> instance;
    for (const auto & item : base.monoms)
    {
        instance.push_back (
            polynomial::Monom {
                .coef = item.coef * multiplier.coef,
                .power = item.power + multiplier.power
            }
        );
    }
    return polynomial (instance);
}
polynomial operator* (const polynomial::Monom & multiplier, const polynomial & base)
{
    return base * multiplier;
}
polynomial& polynomial::operator*= (const Monom & multiplier)
{
    for (auto & item : this->monoms)
    {
        item.coef *= multiplier.coef;
        item.power += multiplier.power;
    }
    return *this;
}
polynomial operator* (const polynomial & left, const polynomial & right)
{
    list<polynomial::Monom> instance;
    for (const auto & item : right.monoms)
    {
        polynomial temp = left * item;
        instance.insert (instance.cend (), temp.monoms.cbegin (), temp.monoms.cend ());
    }
    instance.sort (polynomial::compare);
    polynomial::groupUp (instance);
    return polynomial (instance);
}
polynomial& polynomial::operator*= (const polynomial & other)
{
    for (auto item = this->monoms.begin (); item != this->monoms.end (); ++item)
    {
        polynomial temp = (*this) * (*item);
        this->monoms.erase (item);
        for (const auto & monom : temp.monoms)
        {
            this->monoms.push_back (monom);
        }
    }
    this->monoms.sort (compare);
    groupUp (this->monoms);
    return *this;
}

polynomial operator/ (const polynomial & base, const double divider)
{
    polynomial instance (base);
    for (auto & item : instance.monoms)
    {
        item.coef /= divider;
    }
    return instance;
}
polynomial& polynomial::operator/= (const double divider)
{
    for (auto & item : this->monoms)
    {
        item.coef /= divider;
    }
    return *this;
}
polynomial operator/ (const polynomial & base, const polynomial::Monom & divider)
{
    polynomial instance (base);
    for (auto & item : instance.monoms)
    {
        item.coef /= divider.coef;
        item.power -= divider.power;
    }
    return instance;
}
polynomial& polynomial::operator/= (const Monom & divider)
{
    for (auto & item : this->monoms)
    {
        item.coef /= divider.coef;
        item.power -= divider.power;
    }
    return *this;
}
polynomial operator/ (const polynomial & base, const polynomial & divider)
{
    if (divider.empty () || divider.zero ())
    {
        return polynomial {};
    }
    if (divider.power () > base.power ())
    {
        return polynomial (polynomial::Monom {0, 0});
    }
    list<polynomial::Monom> instance;
    polynomial temp (base);
    polynomial::Monom multiplier {};
    while (temp.power () >= divider.power ())
    {
        multiplier.coef = temp.monoms.cbegin ()->coef / divider.monoms.cbegin ()->coef;
        multiplier.power = temp.monoms.cbegin ()->power - divider.monoms.cbegin ()->power;
        temp -= (divider * multiplier);
        instance.push_back (
            polynomial::Monom {
                .coef = multiplier.coef,
                .power = multiplier.power
            }
        );
    }

    return polynomial (instance);
}
polynomial& polynomial::operator/= (const polynomial & divider)
{
    if (divider.empty () || divider.zero ())
    {

    }
    if (divider.power () > this->power ())
    {
        this->clear ();
        this->monoms.push_back (
            Monom {
                .coef = 0.0f,
                .power = 0
            }
        );
    }

    Monom multiplier {};
    while (this->power () >= divider.power ())
    {
        multiplier.coef = this->monoms.cbegin ()->coef / divider.monoms.cbegin ()->coef;
        multiplier.power = this->monoms.cbegin ()->power - divider.monoms.cbegin ()->power;
        *this -= (divider * multiplier);
    }

    return *this;
}

bool operator== (const polynomial & left, const polynomial & right)
{
    if (left.monoms.size() != right.monoms.size ())
        return false;

    for (auto leftIt = left.monoms.cbegin (), rightIt = right.monoms.cbegin (); leftIt != left.monoms.cend (); ++leftIt, ++rightIt)
    {
        if (leftIt->power != rightIt->power || leftIt->coef != rightIt->coef)
            return false;
    }
    return true;
}
bool operator!= (const polynomial & left, const polynomial & right)
{
    return !(left == right);
}

polynomial polynomial::pow (unsigned power) const
{
    if (power == 0)
        return polynomial (Monom {1.0f, 0});
    else
    {
        polynomial instance (*this);
        while (power > 1)
        {
            instance = instance * (*this);
            --power;
        }
        return instance;
    }
}
double polynomial::super (const double X) const
{

    auto iterator = this->monoms.cbegin ();
    double sum = iterator->coef;
    unsigned prev_power = iterator->power;
    ++iterator;
    for (; iterator != this->monoms.cend (); ++iterator)
    {
        while (prev_power > iterator->power)
        {
            sum *= X;
            --prev_power;
        }
        sum += iterator->coef;
    }
    return sum;
}
polynomial polynomial::super (const polynomial & X) const
{
    polynomial instance;
    unsigned power = 0;
    polynomial x ("1");

    for (auto iterator = this->monoms.crbegin (); iterator != this->monoms.crend (); ++iterator)
    {
        while (iterator->power > power)
        {
            x = x * X;
            ++power;
        }
        instance += iterator->coef * x;
    }

    return instance;
}

bool polynomial::empty () const
{
    return this->monoms.empty ();
}
bool polynomial::zero () const
{
    for (const auto & item : this->monoms)
    {
        if (item.coef != 0.0f)
        {
            return false;
        }
    }
    return true;
}
unsigned polynomial::length () const
{
    return this->monoms.size ();
}
polynomial::power_t polynomial::power () const
{
    return (this->monoms.cbegin ()->power);
}

const polynomial::Monom& polynomial::head () const
{
    return *(this->monoms.cbegin ());
}

void polynomial::clear ()
{
    this->monoms.clear ();
}

void polynomial::print () const
{
    if (this->empty () || this->zero ())
    {
        cout << '0';
    }
    else
    {
        auto iterator = this->monoms.cbegin ();

        if (iterator->coef < 0.0f)
        {
            cout << '-';
        }
        if (iterator->power == 0 || (iterator->coef != 1.0 && iterator->coef != -1.0f))
            cout << ((iterator->coef < 0.0f) ? -iterator->coef : iterator->coef);

        if (iterator->power != 0)
        {
            cout << 'x';
            if (iterator->power != 1)
            {
                cout << '^';
                cout << iterator->power;
            }
        }
        ++iterator;
        for (; iterator != this->monoms.cend (); ++iterator)
        {
            cout << ((iterator->coef < 0.0f) ? " - " : " + ");
            if (iterator->coef != 1.0f && iterator->coef != -1.0f)
            {
                cout << ((iterator->coef < 0.0f) ? -iterator->coef : iterator->coef);
            }
            if (iterator->power != 0)
            {
                cout << 'x';
                if (iterator->power != 1)
                {
                    cout << '^' << iterator->power;
                }
            }
        }
    }
}
